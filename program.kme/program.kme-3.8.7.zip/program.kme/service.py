import xbmc, xbmcgui, os, json, requests , re, urllib
import pvr, wall
from resources.lib.modules import control
control.moderator()

def UpdateDomain():
	try:
		response = requests.get("https://raw.githubusercontent.com/Apollo2000/Repo/master/domain.txt", verify=False)
		data = json.loads(response.text)
		control.addon().setSetting('domain', data['result'])
	except: 
		control.addon().setSetting('domain', "89to.com")
		pass

def versiontuple(v):
    return tuple(map(int, (v.split("."))))

def CheckAddonUpdate():
	try:
		folder = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo'))
		if not os.path.isdir(folder):
			os.makedirs(folder)
			xml_file = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo','addon.xml'))
			icon_file = xbmc.translatePath(os.path.join('special://home','addons','repository.apollo','icon.png'))
			urllib.urlretrieve ("https://raw.githubusercontent.com/Apollo2000/Repo/master/repository.apollo/addon.xml", xml_file)
			urllib.urlretrieve ("https://raw.githubusercontent.com/Apollo2000/Repo/master/repository.apollo/icon.png", icon_file)
	except: pass
	
	if control.addon().getSetting('firstRun')=="true":
		if control.addon().getSetting('email')== "":
			i = xbmcgui.Dialog().yesno("Apollo Group","Are you a member ?")
			if i == 1:
				email = xbmcgui.Dialog().input('Enter Member Email', type=xbmcgui.INPUT_ALPHANUM)
				control.addon().setSetting('email', str(email))
				password = xbmcgui.Dialog().input('Enter Member Password', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
				control.addon().setSetting('password', str(password))
			else:
				xbmcgui.Dialog().ok('Apollo Group',"Free users have limit access. Get membership at FB @ApolloGroupTV or website ApolloGroup.tv")
		control.addon().setSetting('firstRun', 'false')
		xbmc.sleep(10)

	LocalVersion = control.addon().getAddonInfo('version')
	try:
		response = requests.get("https://raw.githubusercontent.com/Apollo2000/Repo/master/program.apollo/addon.xml")
		match = re.search (r'version="(\d\.\d\.\d)"', response.text,re.M|re.I)
	except: 
		pass

	if not match:
		return
	RemoteVersion = match.groups()[0]

	STRversion = str(LocalVersion)+"/"+str(RemoteVersion)
	if not control.addon().getSetting('version')==str(STRversion):
		control.addon().setSetting('version', str(STRversion))

	if versiontuple(RemoteVersion) > versiontuple(LocalVersion):
		xbmc.executebuiltin('Notification(Apollo Group,"Please wait, Updating Addon to {0}.", 5000,{1})'.format(RemoteVersion,os.path.join(control.addonPath ,"icon.png")))
		xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
		sys.exit(1)

if control.addon().getAddonInfo('id')=="program.apollo":
	UpdateDomain()
	CheckAddonUpdate()

pvr.runPVR()
xbmc.sleep(10000)
xbmc.executebuiltin("RunPlugin(plugin://%s)" % (control.addon().getAddonInfo('id')+"/?action=login&hide=1"));
xbmc.sleep(60000)
wall.runWall()
		

command = "RunPlugin(plugin://%s)" % control.addon().getAddonInfo('id')+"/wall.py"
xbmc.executebuiltin("AlarmClock(MyAddonWall,%s,130,false,true)" % command )

command = "RunPlugin(plugin://%s)" % control.addon().getAddonInfo('id')+"/?action=login&hide=1"
xbmc.executebuiltin("AlarmClock('MyAddonLogin',%s,360,true,true)" % command)

command = "RunPlugin(plugin://%s)" % control.addon().getAddonInfo('id')+"/pvr.py"
xbmc.executebuiltin("AlarmClock(MyAddonPVR,%s,60,false,true)" % command )
