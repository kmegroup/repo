# -*- coding: utf-8 -*-

from requests import get

from resources.lib.modules import control

import sys,re,json,urllib,urlparse,datetime,xbmc,xbmcgui

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')

control.moderator()

class xxx:
	def __init__(self):
		self.list = [] ; self.items = []

	def get(self,name): 
		response = get(control.myaddon_static_link+"info/tt6969696.json", verify=False)
		data = json.loads(response.text)
		if name==None:
			for cat in data['result']:
				try: 
					self.list.append({'id': str(cat['id']),'name': str(cat['name']),'url':str(cat['id']),'poster':str(cat['poster'])})
				except: 
					print "####### ERROR Getting List from Server: %s" % cat
					pass
		elif name>0:
			for cat in data['result']:
				try: 
					if str(cat['id']) == str(name):
						for channel in cat['episodes']:
							try: 
								self.list.append({'id': str(channel["id"]),'name': str(channel["name"].encode('utf-8')),'title':'','hd': 1, 'url': 'plugin://'+control.addon().getAddonInfo('id')+'/?action=myaddon&imdb=tt6969696&season=%s&episode=%s&title=%s&year=2018'%(cat['id'],channel['id'],str(channel["name"].encode('utf-8'))),'poster': str(cat['poster'])})
							except:
								print "####### ERROR Getting List from Server1: %s %s"%(str(channel['id']),channel)
								pass
				except: 
					print "####### ERROR Getting List from Server: %s" % cat
					pass
		
			try: self.list = sorted(self.list, key=lambda k: k['name'])
			except: pass

		self.channelDirectory(self.list,name)
		return self.list

	def channelDirectory(self, items,name):
		if items == None or len(items) == 0: control.idle() ; sys.exit()

		sysaddon = sys.argv[0]

		syshandle = int(sys.argv[1])

		addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

		addonFanart = control.addonFanart()

		try: isOld = False ; control.item().getArt('type')
		except: isOld = True

		isPlayable = 'true' if not 'plugin' in control.infoLabel('Container.PluginName') else 'false'

		if name==None:
			for i in items:
				try:
					item = control.item(label=i['name'])
					item.setInfo(type='Video', infoLabels = "")
					item.addStreamInfo('video', { 'width':1920 ,'height' : 1080 })
					item.setProperty('Video', 'true')
					control.addItem(handle=int(sys.argv[1]), url="plugin://"+control.addon().getAddonInfo('id')+"/?action=moviesXXX&name="+i['url'], listitem=item, isFolder=True)
				except:	pass
		else:
			for i in items:
				try:
					label = '[B]%s[/B]' % (i['name'])
					sysname = urllib.quote_plus('%s' % (i['name']))
					systitle = urllib.quote_plus(i['name'])
					poster = i['poster']
					banner = '0'
					url = i['url']
					sysurl = urllib.quote_plus(url)

					cm = []

					#cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

					#cm.append((refreshMenu, 'RunPlugin(%s?action=refresh)' % sysaddon))

					#cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))

					if isOld == True:
						cm.append((control.lang2(19033).encode('utf-8'), 'Action(Info)'))


					item = control.item(label=label)
					if (str(i['hd'])=="1"):
						item.addStreamInfo('video', { 'width':1280 ,'height' : 720 })
					elif (str(i['hd'])=="2"):
						item.addStreamInfo('video', { 'width':1920 ,'height' : 1080 })
					else:
						item.addStreamInfo('video', { 'width':600 ,'height' : 320 })

					item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': banner})

					if not addonFanart == None:
						item.setProperty('Fanart_Image', addonFanart)

					item.addContextMenuItems(cm)
					item.setProperty('IsPlayable', isPlayable)
					item.setInfo(type='Video', infoLabels = "")

					control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
				except:
					pass

		control.content(syshandle, 'movies')
		#control.do_block_check(False)
		control.directory(syshandle, cacheToDisc=True)


